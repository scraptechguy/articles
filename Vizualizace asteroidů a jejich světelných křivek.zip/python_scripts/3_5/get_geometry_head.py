    def get_geometry(self):
        self.centers = []
        self.normals = []