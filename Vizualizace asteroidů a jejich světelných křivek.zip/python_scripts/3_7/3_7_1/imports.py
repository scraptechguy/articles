import numpy as np
import vispy.app
import vispy.scene