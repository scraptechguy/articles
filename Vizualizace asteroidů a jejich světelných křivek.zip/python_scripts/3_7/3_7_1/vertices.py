    A = np.array((1, 0, 0))
    B = np.array((0, 1, 0))
    C = np.array((0, 0, 1))