    asteroid = Asteroid(args=args, filename=filename)
    vispy.app.run()

if __name__ == "__main__":
    main()